import cookieParser from "cookie-parser";

// Export middleware
export default cookieParser();
